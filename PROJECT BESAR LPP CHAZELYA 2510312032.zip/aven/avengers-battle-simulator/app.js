const express = require("express");
const fs = require("fs").promises;
const app = express();

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.set("view engine", "ejs");

// PAGE 1
app.get("/", (req, res) => {
  res.render("home");
});

// PAGE 2
app.get("/select", (req, res) => {
  res.render("select");
});
async function saveBattleLog(data) {
  const file = await fs.readFile("data/battle-log.json", "utf-8");
  const logs = JSON.parse(file);

  logs.push(data);

  await fs.writeFile(
    "data/battle-log.json",
    JSON.stringify(logs, null, 2)
  );
}

// PAGE 3
app.post("/battle", async (req, res) => {
  const power = {
    ironman: 70,
    captain: 75,
    thor: 90,
    hulk: 95,
    widow: 65,
    hawkeye: 60,
  };

  const { a, b } = req.body;

  let totalA = 0;
  let totalB = 0;

  for (let i = 0; i < 3; i++) {
    totalA += power[a] + Math.floor(Math.random() * 20);
    totalB += power[b] + Math.floor(Math.random() * 20);
  }

  res.render("battle", { a, b, totalA, totalB });
});

// PAGE 4
app.post("/result", (req, res) => {
  const { a, b, totalA, totalB } = req.body;
  const winner = Number(totalA) > Number(totalB) ? a : b;

  res.render("result", { a, b, totalA, totalB, winner });
});

await saveBattleLog({
  playerA: a,
  playerB: b,
  scoreA: totalA,
  scoreB: totalB,
  winner: totalA > totalB ? a : b,
  time: new Date()
});

// SERVER
app.listen(3000, () => {
  console.log("Server running http://localhost:3000");
});

app.post("/battle", (req, res) => {
  const { a, b } = req.body;

  // HARD VALIDATION
  if (a === b) {
    return res.redirect("/select");
  }

  // lanjut battle normal
  res.render("battle", { a, b });
});
const fs = require("fs").promises;

async function saveBattleLog(data) {
  const file = await fs.readFile("data/battle-log.json", "utf-8");
  const logs = JSON.parse(file);
  logs.push(data);
  await fs.writeFile("data/battle-log.json", JSON.stringify(logs, null, 2));
}
const expressLayouts = require("express-ejs-layouts");
app.use(expressLayouts);
app.set("layout", "layout");
