const Hero = require("/Hero");

class Avenger extends Hero {
  constructor(name, stamina, attack) {
    super(name, stamina);
    this.attack = attack;
  }

  getPower() {
    return this.stamina + this.attack;
  }
}

module.exports = Avenger;
