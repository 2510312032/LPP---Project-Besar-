class Hero {
  constructor(name, stamina) {
    this.name = name;
    this.stamina = stamina;
  }

  getPower() {
    return this.stamina;
  }
}

module.exports = Hero;
