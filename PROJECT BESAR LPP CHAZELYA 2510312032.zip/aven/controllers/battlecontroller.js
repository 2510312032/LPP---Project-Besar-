const power = {
  ironman: 40,
  captain: 45,
  thor: 60,
  hulk: 70,
  widow: 35,
  hawkeye: 30
};

function getPower(hero) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(power[hero]);
    }, 300);
  });
}

exports.fight = async (req, res) => {
  const { a, b } = req.body;

  const powerA = await getPower(a);
  const powerB = await getPower(b);

  let winner = "draw";
  if (powerA > powerB) winner = a;
  else if (powerB > powerA) winner = b;

  res.render("battle", {
    charA: a,
    charB: b,
    winner
  });
};
